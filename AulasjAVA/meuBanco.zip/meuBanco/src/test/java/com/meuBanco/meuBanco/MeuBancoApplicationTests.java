package com.meuBanco.meuBanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeuBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
