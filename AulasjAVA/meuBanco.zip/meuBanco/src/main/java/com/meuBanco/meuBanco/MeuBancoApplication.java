package com.meuBanco.meuBanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuBancoApplication.class, args);
	}

}
