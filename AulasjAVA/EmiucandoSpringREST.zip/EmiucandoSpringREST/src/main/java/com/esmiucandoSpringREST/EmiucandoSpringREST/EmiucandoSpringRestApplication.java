package com.esmiucandoSpringREST.EmiucandoSpringREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmiucandoSpringRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmiucandoSpringRestApplication.class, args);
	}

}
