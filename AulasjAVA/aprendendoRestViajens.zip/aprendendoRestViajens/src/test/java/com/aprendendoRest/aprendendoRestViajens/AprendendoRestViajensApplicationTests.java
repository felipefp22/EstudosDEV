package com.aprendendoRest.aprendendoRestViajens;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AprendendoRestViajensApplicationTests {

	@Test
	void contextLoads() {
	}

}
