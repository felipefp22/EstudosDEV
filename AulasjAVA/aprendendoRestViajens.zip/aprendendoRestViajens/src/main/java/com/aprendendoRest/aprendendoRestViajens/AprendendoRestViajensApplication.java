package com.aprendendoRest.aprendendoRestViajens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AprendendoRestViajensApplication {

	public static void main(String[] args) {
		SpringApplication.run(AprendendoRestViajensApplication.class, args);
	}

}
