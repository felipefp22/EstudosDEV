package com.felipefp2.userDepartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
