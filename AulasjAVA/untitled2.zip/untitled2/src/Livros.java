

public class Livros {

    private String nomeLivro;
    private String nomeAutor;
    private String dadosLivro;

}


